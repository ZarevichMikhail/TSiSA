import numpy as np
damage = [5, 10, 13, 16, 20] # ущерб по категориям
expenses = [2, 4, 6, 8, 10] # затраты на дамбы


# создаем матрицу
damb = 5 # дамбы
flood = 5 # категория наводнения

matrix = np.zeros((damb, flood)) # нулевая матрица 5х5, по вертикали высота дамбы, по горизонтали может ли наводнение пробить дамбу

for i in range(damb):    # Перебор дамб (h1-h5)
    for j in range(flood):    # Перебор категорий наводнения (1-5)
        if (j + 1) <= (i + 1):   # Если дамба защищает
            matrix[i, j] = -expenses[i]
        else:                     # Если не защищает
            matrix[i, j] = -(damage[j] + expenses[i])


print("Матрица выигрышей/потерь:")
print(matrix)

# Критерии
def laplace(matrix):
    return np.argmax(np.mean(matrix, axis=1)) # средний результат

def wald(matrix):
    return np.argmax(np.min(matrix, axis=1)) # берем худший случай (наводнение 5) и выбираем высоту с наименьшими потерями

def maximax(matrix):
    return np.argmax(np.max(matrix, axis=1)) # берем лучший вариант (наводнение 1) и выбираем наилучший вариант

def savage(matrix):
    losses = np.max(matrix, axis=0) - matrix # матрица потерь
    print("Сожаления:")
    print(losses)
    return np.argmin(np.max(losses, axis=
1)) # ищем минимальное упущение

def hurwitz(matrix, a):
    hurwitz_values = a * np.max(matrix, axis=1) + (1 - a) * np.min(matrix, axis=1)
    print(f"Значения по Гурвицу: {hurwitz_values}")
    return np.argmax(hurwitz_values) # среднее между wald и maximax


print("\nОптимальные решения:")
print(f"Лапласа: h{laplace(matrix) + 1}")
print(f"Вальда: h{wald(matrix) + 1}")
print(f"Максимакса: h{maximax(matrix) + 1}")
print(f"Сэвиджа: h{savage(matrix) + 1}")
print(f"Гурвица: h{hurwitz(matrix, 0.7) + 1}")