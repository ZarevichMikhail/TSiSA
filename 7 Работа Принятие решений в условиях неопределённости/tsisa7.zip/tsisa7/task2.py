#  Постройте матрицу выигрышей / потерь. Найдите оптимальные решения,
# используя критерии Лапласа, Вальда, максимакса, Сэвиджа, Гурвица (оптимизм α = 0.7).

import numpy as np

Pi =[30, 80, 50, 200, 380]
Ci = [14, 6, 10, 5, 4]
Q = [150, 200, 250, 300, 350]


matrix = []
for i in range(len(Pi)):
    temp = []
    for j in range(len(Q)):
        temp.append(-(Pi[i]+ Ci[i]*Q[j]))
    matrix.append(temp)
for i in matrix:
    print(i)

# Для 2 кр
"""matrix = [[-5,35,15],
          [20,9,2],
          [10,7,12],
          [4,30,10]]
"""


"""matrix = [[20,15,10],
          [16,12,14],
          [13,18,15]]"""

# Критерии
def laplace(matrix):
    return np.argmax(np.mean(matrix, axis=1)) # средний результат

def wald(matrix):
    return np.argmax(np.min(matrix, axis=1)) # берем худший случай (наводнение 5) и выбираем высоту с наименьшими потерями

def maximax(matrix):
    return np.argmax(np.max(matrix, axis=1)) # берем лучший вариант (наводнение 1) и выбираем наилучший вариант

def savage(matrix):
    losses = np.max(matrix, axis=0) - matrix # матрица потерь
    print("Потери:")
    print(losses)
    return np.argmin(np.max(losses, axis=1)) # ищем минимальное упущение

def hurwitz(matrix, a):
    hurwitz_values = a * np.max(matrix, axis=1) + (1 - a) * np.min(matrix, axis=1)
    print(f"Значения по Гурвицу: {hurwitz_values}")
    return np.argmax(hurwitz_values) # среднее между wald и maximax


print("\nОптимальные решения:")
print(f"Лапласа: h{laplace(matrix) + 1}")
print(f"Вальда: h{wald(matrix) + 1}")
print(f"Максимакса: h{maximax(matrix) + 1}")
print(f"Сэвиджа: h{savage(matrix) + 1}")
print(f"Гурвица: h{hurwitz(matrix, 0.7) + 1}")